# Harry Potter and the Chamber of Secrets

## Page 352

“Cool,” said Dean. “Amazing,” said Neville, awestruck. Harry couldn’t help it. He grinned, too.