# Harry Potter and the Chamber of Secrets

## Page 399

W CHAPTER NINE THE WRITING ON THE WALL hat’s going on here? What’s going on?” Attracted no doubt by Malfoy’s shout, Argus Filch came shouldering his way through the crowd. Then he saw Mrs. Norris and fell back, clutching his face in horror. “My cat! My cat! What’s happened to Mrs. Norris?” he shrieked. And his popping eyes fell on Harry. “You!” he screeched. “You! You’ve murdered my cat! You’ve killed her! I’ll kill you! I’ll —” “Argus!” Dumbledore had arrived on the scene, followed by a number of other teachers. In seconds, he had swept past Harry, Ron, and Hermione and detached Mrs. Norris from the torch bracket. “Come with me, Argus,” he said to Filch. “You, too, Mr. Potter, Mr. Weasley, Miss Granger.”