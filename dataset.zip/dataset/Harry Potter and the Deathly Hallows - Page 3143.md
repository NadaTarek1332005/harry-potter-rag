# Harry Potter and the Deathly Hallows

## Page 3143

he was too weak at the knees to stand properly. When finally he was able to totter a few steps they all accompanied him to his cupboard, watched him tuck up the locket safely in his dirty blankets, and assured him that they would make its protection their first priority while he was away. He then made two low bows to Harry and Ron, and even gave a funny little spasm in Hermione’s direction that might have been an attempt at a respectful salute, before Disapparating with the usual loud crack.