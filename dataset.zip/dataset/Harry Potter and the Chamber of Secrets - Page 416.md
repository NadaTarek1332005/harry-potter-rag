# Harry Potter and the Chamber of Secrets

## Page 416

book called Moste Potente Potions and it’s bound to be in the Restricted Section of the library.” There was only one way to get out a book from the Restricted Section: You needed a signed note of permission from a teacher. “Hard to see why we’d want the book, really,” said Ron, “if we weren’t going to try and make one of the potions.” “I think,” said Hermione, “that if we made it sound as though we were just interested in the theory, we might stand a chance. . . .” “Oh, come on, no teacher’s going to fall for that,” said Ron. “They’d have to be really thick. . . .”