# Harry Potter and the Chamber of Secrets

## Page 334

But it was a subdued group that headed back to the fireside in the Leaky Cauldron, where Harry, the Weasleys, and all their shopping would be traveling back to the Burrow using Floo powder. They said good-bye to the Grangers, who were leaving the pub for the Muggle street on the other side; Mr. Weasley started to ask them how bus stops worked, but stopped quickly at the look on Mrs. Weasley’s face. Harry took off his glasses and put them safely in his pocket before helping himself to Floo powder. It definitely wasn’t his favorite way to travel.