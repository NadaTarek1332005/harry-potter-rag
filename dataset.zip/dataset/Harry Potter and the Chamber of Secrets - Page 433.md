# Harry Potter and the Chamber of Secrets

## Page 433

“What does this mean, Albus?” Professor McGonagall asked urgently. “It means,” said Dumbledore, “that the Chamber of Secrets is indeed open again.” Madam Pomfrey clapped a hand to her mouth. Professor McGonagall stared at Dumbledore. “But, Albus . . . surely . . . who?” “The question is not who,” said Dumbledore, his eyes on Colin. “The question is, how. . . .” And from what Harry could see of Professor McGonagall’s shadowy face, she didn’t understand this any better than he did.